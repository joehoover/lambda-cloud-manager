# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lambda_cloud_manager']

package_data = \
{'': ['*']}

install_requires = \
['python-dotenv>=0.21.1,<0.22.0',
 'requests>=2.28.2,<3.0.0',
 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['lcm = lambda_cloud_manager.main:app']}

setup_kwargs = {
    'name': 'lambda-cloud-manager',
    'version': '0.1.0',
    'description': '',
    'long_description': '# lambda-cloud-manager\n\nLambda-cloud-manager is a lightweight command line tool and Python SDK that helps manage Lambda Cloud Instances via the Cloud API. \n\n## Installation\n\nCurrently, poetry is the easiest way to install the package. Just run:\n\n```bash\npoetry add git+https://github.com/joehoover/lambda-cloud-manager.git\n```\n\n## CLI Usage\n\n1. Store your Lambda Cloud API Key as an environmental variable: \n\n    ```bash\n    export LAMBDA_API_KEY="<your-key-here>"\n    ```\n2. Interact with the Lambda Cloud API via your CLI using the lcm tool. The following commands are supported:\n\n   * `get-instance-types`\n   * `get-instances`\n   * `ssh-keys`\n   * `write-config`\n   * `launch`       \n   * `terminate`\n\n### Example: Launch a single a10 instance\n\n#### Instance Selection\nFirst, let\'s see what instances are available. \n\n```bash\nlcm get-instance-types\n```\n\nThis logs Lambda Cloud instance types to the console. And, when we find the `gpu_1x_a10` instance, we see:\n\n```json\n{\n   "gpu_1x_a10": {\n      "instance_type": {\n         "name": "gpu_1x_a10",\n         "price_cents_per_hour": 60,\n         "description": "1x A10 (24 GB PCIe)",\n         "specs": {\n            "vcpus": 30,\n            "memory_gib": 200,\n            "storage_gib": 1400\n         }\n      },\n      "regions_with_capacity_available": [\n         {\n            "name": "us-west-1",\n            "description": "California, USA"\n         }\n      ]\n   }\n}\n```\n\n#### Config Specification \n\nLet\'s go ahead and generate a config for this instance. We just need to specify the path for our config:\n\n```bash\nlcm generate-config ./configs/a10.json\n```\n\nThis will log the following to your console:\n\n```bash\nINFO:root:Wrote the following config to `configs/test.json`...\nINFO:root:{\n    "region_name": "us-west-1",\n    "instance_type_name": "gpu_1x_a10",\n    "ssh_key_names": [\n        ""\n    ],\n    "file_system_names": [],\n    "quantity": 1\n}\n\n```\n\nNow, you need to add your Lambda Cloud ssh key name to the config. If you haven\'t created one, do that now. Or if you do have one, but you can\'t remember the name, you can just run:\n\n```bash\nlcm ssh-keys\n```\n\nwhich will return information about your configured SSH keys. \n\n#### Launching your instance\n\nTo launch your instance, you can just run:\n\n```bash\nlcm launch ./configs/a10.json --name test-instance\n```\n\nThis will log a response like: \n\n```json\n{\n    "instance_ids": [\n        "bd7cb0ccfb574f6c876f6c9b1ba5ad38"\n    ]\n}\n```\n\n### Checking for live instances\n\nLet\'s see if it\'s running:\n\n```bash\nlcm get-instances\n```\n\n### Terminating instances\n\nYou can terminate instances by name:\n\n```bash\nlcm terminate --name test-instance\n```\n\nor in bulk:\n\n```bash\nlcm terminate --all\n```\n',
    'author': 'Joe Hoover',
    'author_email': 'joehoover88@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
